
export default class Item{

    constructor(quantidade,ValorUnitario,mercadorias_idmercadorias) {
        this.quantidade = quantidade;
        this.ValorUnitario = ValorUnitario;
       
        this.mercadoria=mercadorias_idmercadorias
       
        
    }
}