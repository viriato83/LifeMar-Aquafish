

export default class  Mortalidade{

    constructor(descricao,quantidade,data){
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.data = data;
    }
}
