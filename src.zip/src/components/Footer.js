

export default function Footer(){
    return(  <footer>
        <p>&copy; 2025 LifeMar LDA. Todos os direitos reservados.</p>
    </footer>)
}