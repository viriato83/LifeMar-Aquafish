


export default function Loading() {
    return (
      <div className="loading-spinner-overlay">
          <div className='spinner-border text-primary d-flex justify-content-center align-items-lg-center'   style={{ width: '3rem', height: '3rem' }}>
              <div className='spinner-grow spinner-grow-sm '  style={{ width: '2rem', height: '2rem' }}>

              </div>
          </div>
 
      </div>
    );
  }