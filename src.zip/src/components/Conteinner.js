

export default function Conteinner({children}){
    return (
        <div className=" container-fluid ">
             
           {children}
             
           
          
         
        </div>
    )
}